This file contains materials for one instance of the attacklab.

本文件包含 Attack Lab（攻击实验）某一个具体实验实例（instance）的配套材料（materials）。

Files:

    ctarget

Linux binary with code-injection vulnerability.  To be used for phases
1-3 of the assignment.

这是一个具有代码注入漏洞（code-injection vulnerability）的 Linux 二进制可执行程序（binary），用于本作业（assignment）的第 1–3 个阶段（phases）。

    rtarget

Linux binary with return-oriented programming vulnerability.  To be
used for phases 4-5 of the assignment.

这是一个具有返回导向编程漏洞（return-oriented programming vulnerability，ROP）的 Linux 二进制可执行程序（binary），用于本作业的第 4–5 个阶段（phases）。

     cookie.txt

Text file containing 4-byte signature required for this lab instance.

该文本文件包含本实验实例（lab instance）所需的 4 字节签名（4-byte signature）。

     farm.c

Source code for gadget farm present in this instance of rtarget.  You
can compile (use flag -Og) and disassemble it to look for gadgets.

该文件包含此 `rtarget` 实例中的指令片段库（gadget farm）源代码（source code）。你可以先编译（compile，使用 `-Og` 选项），再对其反汇编（disassemble），以查找可用的指令片段（gadgets）。

     hex2raw

Utility program to generate byte sequences.  See documentation in lab
handout.

这是生成字节序列（byte sequences）的工具程序（utility program）。具体用法见实验发放材料（lab handout）中的说明文档（documentation）。

