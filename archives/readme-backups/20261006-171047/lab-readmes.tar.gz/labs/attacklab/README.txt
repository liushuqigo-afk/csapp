This file contains materials for one instance of the attacklab.

【中文翻译】
本文件包含 Attack Lab（攻击实验）某一个具体实验实例（instance）的配套材料（materials）。

Files:

【中文翻译】
文件清单（Files）：

    ctarget

【中文翻译】
`ctarget`：该实例中的代码注入目标程序（code-injection target）。

Linux binary with code-injection vulnerability.  To be used for phases
1-3 of the assignment.

【中文翻译】
这是一个具有代码注入漏洞（code-injection vulnerability）的 Linux 二进制可执行程序（binary），用于本作业（assignment）的第 1–3 个阶段（phases）。

    rtarget

【中文翻译】
`rtarget`：该实例中的返回导向编程目标程序（return-oriented programming target）。

Linux binary with return-oriented programming vulnerability.  To be
used for phases 4-5 of the assignment.

【中文翻译】
这是一个具有返回导向编程漏洞（return-oriented programming vulnerability，ROP）的 Linux 二进制可执行程序（binary），用于本作业的第 4–5 个阶段（phases）。

     cookie.txt

【中文翻译】
`cookie.txt`：保存本实验实例识别值（cookie）的文本文件。

Text file containing 4-byte signature required for this lab instance.

【中文翻译】
该文本文件包含本实验实例（lab instance）所需的 4 字节签名（4-byte signature）。

     farm.c

【中文翻译】
`farm.c`：本实验实例的指令片段库（gadget farm）源文件。

Source code for gadget farm present in this instance of rtarget.  You
can compile (use flag -Og) and disassemble it to look for gadgets.

【中文翻译】
该文件包含此 `rtarget` 实例中的指令片段库（gadget farm）源代码（source code）。你可以先编译（compile，使用 `-Og` 选项），再对其反汇编（disassemble），以查找可用的指令片段（gadgets）。

     hex2raw

【中文翻译】
`hex2raw`：用于把十六进制表示（hexadecimal representation）转换为原始字节（raw bytes）的工具程序。

Utility program to generate byte sequences.  See documentation in lab
handout.

【中文翻译】
这是生成字节序列（byte sequences）的工具程序（utility program）。具体用法见实验发放材料（lab handout）中的说明文档（documentation）。

